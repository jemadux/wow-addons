** HealBot Continued **

Latest Download from Curse: http://www.curse.com/addons/wow/heal-bot-continued



=================================
--- Installation and Updating ---
=================================

Installing and Updating
-----------------------

1: Completely log off WoW
2: Unzip the downloaded
3: Copy the HealBot folders into your WoW Addons folder.
4: Logon to WoW on your main Healer.
5: As a priority you should open the options and configure spells, cures and buffs.



Updating Troubles
-----------------

***** If you get nil errors after updating *****

1: Completely log off WoW
2: Run the Reset_HealBot.bat file in the Healbot addon folder, this clears old saved Healbot settings from your WTF folder.
3: Logon to WoW on your main Healer.
4: As a priority you should open the options and configure spells, cures and buffs.


